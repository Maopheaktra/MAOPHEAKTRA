<template>
    <div class="card mt-2" v-if="user">
      <div class="card-body">
        <p class="card-text"><strong>Name:{{ user.name }}</strong> </p>
        <p class="card-text"><strong>Email:{{ user.email }}</strong> </p>
        <p class="card-text"><strong>Age: {{ user.age }}</strong> </p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'UserCard',
    props:['user']
  };
  </script>
  
  <style>
  .card {
    margin-top: 1rem;
  }
  </style>