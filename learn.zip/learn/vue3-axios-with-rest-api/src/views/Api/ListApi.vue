<template>
  <div class="container mt-4">
    <h1 class="mb-4">Product List</h1>
    <table class="table table-striped">
      <thead>
        <tr class="text-center">
          <th scope="col">ID</th>
          <th scope="col">PostId</th>
          <th scope="col">Name</th>
          <th scope="col">Email</th>
          <th scope="col">Body</th>
          <!-- <th scope="col">Color</th>
          <th scope="col">Capacity</th>
          <th scope="col">Price</th>
          <th scope="col">Generation</th>
          <th scope="col">Screen Size</th>
          <th scope="col">Year</th>
          <th scope="col">CPU Model</th>
          <th scope="col">Hard Disk Size</th>
          <th scope="col">Description</th> -->
        </tr>
      </thead>
      <tbody>
        <tr v-for="item in listApi" :key="item.id">
          <td>{{ item.id }}</td>
          <td>{{ item.postId }}</td>
          <td>{{ item.name }}</td>
          <td>{{ item.email }}</td>
          <td>{{ item.body }}</td>
          <!-- <td>{{ item.description }}</td>
          <td>{{ item.category }}</td>
          <td>{{ item.subcategory }}</td>
          <td>{{ item.status }}</td>
          <td>{{ item.createdAt }}</td>
          <td>{{ item.updatedAt }}</td>
          <td>{{ item.owner }}</td>
          <td>{{ item.lastUpdatedBy }}</td>
          <td>{{ item.version }}</td> -->
        </tr>
      </tbody>
    </table>
  </div>
</template>
  
  <script>
import axios from "axios";
export default {
  data() {
    return {
      listApi: [],
    };
  },
  mounted() {
    this.fetchApi();
  },
  methods: {
    async fetchApi() {
      try {
        const response = await axios.get("https://jsonplaceholder.typicode.com/comments");
        this.listApi = response.data;
        console.log(this.listApi);
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>