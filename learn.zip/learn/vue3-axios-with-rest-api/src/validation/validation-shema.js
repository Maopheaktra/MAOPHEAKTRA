import * as yup from "yup";

export const categorySchema = yup.object({
    name: yup
        .string()
        .required("This Field is required")
        .min(3, "This field must be at least 3 characters"),
    description: yup.string().required("This Field is required"),
})

export const createCategory = yup.object(
    {
        name: yup
            .string()
            .required("This name is required")
            .min(3, "This field must be at least 3 characters"),
        description: yup.string().required("This Field is required"),
    }
)


export const creteStudent = yup.object({
    name: yup
        .string()
        .required("This name is required")
        .min(3, "This field must be at least 3 characters"),
    dob: yup
        .string()
        .required("This dob is required")
})

export const userSchema = yup.object({
    username: yup
        .string()
        .required("This username is required")
        .min(3, "This field must be at least 3 characters"),
    age: yup
        .number()
        .required("This age is required")
        .min(18, "Age must be greater than 18"),
    email: yup
        .string()
        .required("This email is required")
        .min(3, "This field must be at least 3 characters"),

    password: yup
        .string()
        .required("This password is required")
        .min(3, "This field must be at least 3 characters"),

    confirmPassword: yup
        .string().label('confirm password')
        .required().oneOf([yup.ref('password'), null], 'Passwords must match'),
})