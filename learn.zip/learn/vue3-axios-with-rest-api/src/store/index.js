import { defineStore } from 'pinia'
export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 0,
  }),
  getters: {
    doubleCount: (state) => state.count * 2,
    status(state) {
      if (state.count >= 50) {
        return 'passed';
      } else {
        return 'failed';
      }
    }
  },
  actions: {
    increment() {
      this.count++
    },
    decrement() {
      this.count--
    },


  },
})