<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Product extends Model
{
    use HasFactory, SoftDeletes;
    protected $fillable = ['name','category_id', 'description','media_id'];

    public function category()
    {
        return $this->belongsTo(Category::class,'category_id','id');
    }
    public function media()
    {
        return $this->belongsTo(Medias::class,'media_id','id');
    }
    public function discounts()
    {
        return $this->hasMany(Discount::class);
    }

    public static function list(){
        return self::all();
    }

    public static function create($request, $id = null){
        $data = $request->only('name', 'category_id', 'description','media_id');
        $data = self::updateOrCreate(['id' => $id], $data);
        return $data;
        
    }

}
