<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Medias;
use Illuminate\Http\Request;

class MediaController extends Controller
{
    public function store(Request $request)
    {
        $photo=Medias::store($request);
        return ["success" => true,"data"=>$photo, "Message" =>" created successfully"];
    }
}
